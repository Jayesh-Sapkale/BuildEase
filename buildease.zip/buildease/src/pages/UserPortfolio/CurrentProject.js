// File: src/pages/UserPortfolio/CurrentProject.js

import React, { useState, useEffect } from 'react';
import './CurrentProject.css'; // Import the CSS for this component
import axios from 'axios';

const CurrentProjects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAcceptedProjects = async () => {
      try {
        const response = await axios.get('http://localhost:8081/admin/getAllProjects');
        const filteredProjects = response.data.filter(
          (project) => project.projectStatus === 'ACCEPTED'
        );
        setProjects(filteredProjects);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAcceptedProjects();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="current-projects-container">
      <h3>Current Projects</h3>
      <div className="projects-table">
        {projects.map((project) => (
          <div key={project.projectId} className="project-card">
            <h4>{project.projectName}</h4>
            <table className="project-details-table">
              <thead>
                <tr>
                  <th>Attribute</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Project ID</td>
                  <td>{project.projectId}</td>
                </tr>
                <tr>
                  <td>Status</td>
                  <td>{project.projectStatus}</td>
                </tr>
                <tr>
                  <td>Start Date</td>
                  <td>{project.startDate}</td>
                </tr>
                <tr>
                  <td>End Date</td>
                  <td>{project.endDate}</td>
                </tr>
                <tr>
                  <td>Total Price</td>
                  <td>{project.totalPrice}</td>
                </tr>
                <tr>
                  <td>City</td>
                  <td>{project.city}</td>
                </tr>
                <tr>
                  <td>Builder Name</td>
                  <td>{project.builderName}</td>
                </tr>
                <tr>
                  <td>Customer Name</td>
                  <td>{project.customerName}</td>
                </tr>
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CurrentProjects;
